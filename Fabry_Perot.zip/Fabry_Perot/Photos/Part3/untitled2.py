#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Feb 24 18:06:34 2019

@author: CocoLelio
"""

print ("heute schreibe ich ein script")
